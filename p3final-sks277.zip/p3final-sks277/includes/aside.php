<aside>
  <div class="sidebar">
     <form action="aside.php" method="get">
       <input type="text" />
       <input type="button" name="Search" value="Search"/>
     </form
  Resumes
      <ul>
    <li><a href="journalism.doc">Journalism Resume</a></li>
    <li><a href="marketing.doc">Marketing Resume</a></li>
    <li><a href="theater.doc">Theater and Production Resume</a><li>
    <li><a href="sept-2017.doc">General Resume</a></li>
    </ul>
</div>
</aside>
