<nav>
 <ul>
<li><a href="index.php">Home</a></li>
<li><a href="contact.php">Contact</a></li>
<li><a href="worksamples.php">Work Samples</a></li>
<li><a href="links.php">Links</a></li>
</ul>
</nav>
