<footer>
  For references, please contact sks277@cornell.edu!
</footer>
