<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="style/all.css" media="all"/>
<meta charset="UTF-8">
<title> <strong>Sophie Smith</strong> </title>
</head>
<body>

<h1> Links to my other profiles</h1>
<?php
include("includes/navigation.php");
?>

<?php
 include "includes/aside.php";
?>
<figure>
        <img class="NYDIS" alt="NYDISintern" src="images/NYDISintern.jpg"/>
        <figcaption class="NYDIS">
          Me and my supervisor, Katharina.<br/>
          Source: NYDIS Facebook Page.
        </figcaption>
      </figure>
<p>
  <a class="samples" href="https://www.linkedin.com/in/sophie-smith-1a6589100"> My LinkedIn</a>
</p>
<p>
<a class= "samples" href="https://vimeo.com/sophiesmith14"> Vimeo</a>
</p>

<?php
include("includes/footer.php");
?>
</body>
</html>
